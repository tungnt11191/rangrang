## Module <pos_order_types>

#### 03.10.2019
#### Version 13.0.1.0.0
##### ADD
- Initial commit
